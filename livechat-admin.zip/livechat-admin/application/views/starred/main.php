<div class="row">
  <div class="col-12">
    <div class="card content-margin-right content-top-margin">
      <div class="card-header">
        <h3 class="card-title"><b>Pasar Tiket Jojga</b>
        </h3>
        <h3 class="card-title"><b>Live Chat Admin v1.0</b></h3>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
		<div class="chat chatfield" id="chatfield">
      
  </div>
      <input type="hidden" id="cust_id"/>
</div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>
  <!-- /.col -->
</div>
  <aside class="right-nav">
    <div class="right-nav-upper">
    </div>
    <div class="right-nav-main" id="userList">
      
    </div>
  </aside>