
<nav class="mt-2">
  <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
    
    <li class="nav-header">MENU UTAMA</li>
    
    <li class="nav-item">
      <a href="#" class="nav-link">
        <i class="nav-icon fa fa-dashboard"></i>
        <p>
          Dashboard
          <i class="right fa fa-angle-right"></i>

        </p>
      </a>
    </li>

    <li class="nav-header"><b>Profile</b></li>
    <li class="nav-item has-treeview">
      <a href="#" class="nav-link">
        <i class="fa fa-address-card nav-icon"></i>
        <p>Change Avatar
          <i class="right fa fa-angle-right"></i>
        </p>
      </a>
    </li>
    <li class="nav-item has-treeview">
      <a href="#" class="nav-link">
        <i class="fa fa-retweet nav-icon"></i>
        <p>Change Password
          <i class="right fa fa-angle-right"></i>
        </p>
      </a>
    </li>
    <li class="nav-header"><b>User Chat</b></li>

    <li class="nav-item has-treeview">
      <a href="#" class="nav-link">
        <i class="fa fa-comments nav-icon"></i>
        <p>Chat Messages
          <i class="right fa fa-angle-right"></i>
        </p>
      </a>
       <ul class="nav nav-treeview">
          <li class="nav-item">
            <a href="<?php echo site_url('admin/chat/unread');?>" style="color:#000000;" class="nav-link">
              <i class="fa fa-caret-right nav-icon"></i>
              <p>Unread</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo site_url('admin/chat/');?>" style="color:#000000;" class="nav-link">
              <i class="fa fa-caret-right nav-icon"></i>
              <p>All Chat</p>
            </a>
          </li>
       </ul>
    </li>
    <li class="nav-item has-treeview">
      <a href="<?php echo site_url('admin/starred/');?>" class="nav-link">
        <i class="fa fa-star-half-empty nav-icon"></i>
        <p>Starred Messages
          <i class="right fa fa-angle-right"></i>
        </p>
      </a>
    </li>
    <li class="nav-item has-treeview">
      <a href="<?php echo site_url('admin/trash/');?>" class="nav-link">
        <i class="fa fa-trash nav-icon"></i>
        <p>Trashbin
          <i class="right fa fa-angle-right"></i>
        </p>
      </a>
    </li>
    
    
  </ul>
</nav>