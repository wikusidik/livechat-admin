
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Live Chat Admin</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/datatables/dataTables.bootstrap4.css">
  <!-- Font Awesome -->
  <script src="<?php echo base_url();?>assets/jquery/jquery.min.js"></script>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/adminlte.min.css">
  <?php
    if(isset($css)){
      $this->load->view($css);
    }

    if(isset($toastr) || $toastr){
      echo '<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">';
    }
  ?>
  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-light border-bottom">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="../menu.php" class="nav-link"><i class="fa fa-home"></i> Menu Utama</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="../logout.php" class="nav-link" style="color: red"><i class="fa fa-power-off red"></i> Logout</a>
      </li>
    </ul>
    <div class="right-nav-arrow-button"><i class="fa fa-angle-left right-nav-arrow"></i></div>

  </nav>