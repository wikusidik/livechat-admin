</div>
<!-- ./wrapper -->


<!-- jQuery -->

<!-- jQuery UI 1.11.4 -->
<script src="<?php echo base_url();?>assets/JQueryUI/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url();?>assets/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>assets/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- DataTables -->
<script src="<?php echo base_url();?>assets/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/datatables/dataTables.bootstrap4.js"></script>
<?php
  if(isset($toastr) || $toastr){
    echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>';
  }
  if(isset($js)){
    $this->load->view($js);
  }
?>
</body>
</html>
