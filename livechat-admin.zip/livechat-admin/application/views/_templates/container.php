<?php
    require_once('header.php');
    require_once('index.php');
    require_once('footer.php');
?>