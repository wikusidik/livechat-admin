<style type="text/css">
/*	--lightGreen:#4caf50;
	--deepGreen:#93eac4;
	--greenBlue:#75dbd8;
	--lightBlue:#6dc5df;
	--deepBlue:#408eda;
	--indigo:#6610f2;
	--purple:#6f42c1;
	--pink:#e83e8c;
	--red:#dc3545;
	--orange:#fd7e14;
	--yellow:#ffc107;
	--green:#28a745;
	--teal:#20c997;
	--cyan:#17a2b8;
	--white:#ffffff;
	--gray:#6c757d;
	--gray-dark:#343a40;
	--primary:#007bff;
	--secondary:#6c757d;
	--success:#28a745;
	--info:#17a2b8;
	--warning:#ffc107;*/
    .chat{
	width : 100%;
}
.chatfield{
	width : 100%;
	height : 95%;
	border-width : 1px;
	border-radius : 5px;
	border-color : #dc3545;
	border-style : solid;
	padding-left : 20px;
	padding-right : 20px;
	background : #f2f2f2;
	overflow-y : scroll;
}
@media (min-height : 150px){
	.chatfield{
		max-height : 150px;
		min-height : 120px;
		width : 100%;
		height : 95%;
	}	
}
@media (min-height : 300px){
	.chatfield{
		max-height : 240px;
		min-height : 230px;
		width : 100%;
		height : 95%;
	}	
}
@media (min-height : 480px){
	.chatfield{
		max-height : 360px;
		min-height : 300px;
		width : 100%;
		height : 95%;
	}	
}
@media (min-height : 600px){
	.chatfield{
		max-height : 500px;
		min-height : 480px;
		width : 100%;
		height : 95%;
	}	
}
@media (min-height : 800px){
	.chatfield{
		max-height : 680px;
		min-height : 600px;
		width : 100%;
		height : 95%;
	}	
}
@media (min-height : 992px){
	.chatfield{
		max-height : 870px;
		min-height : 840px;
		width : 100%;
		height : 95%;
	}	
}
@media (min-height : 1080px){
	.chatfield{
		max-height : 960px;
		min-height : 920px;
		width : 100%;
		height : 95%;
	}	
}
@media (min-height : 1200px){
	.chatfield{
		max-height : 990px;
		min-height : 920px;
		width : 100%;
		height : 95%;
	}	
}
.chatspace{
	width : 100%;
	height : 80px;
	clear : both;
}

.chat-menu{
	z-index : 1000;
}

.chatspace:hover .chat-bubble-menu-button{
	display : block;
}

.chat-bubble-menu-button{
	display: none;
	margin-top : 30px;
}
/* chat bubble start ------------------ */
 .chat-bubble-left {
    background: #6dc5df;
    -webkit-border-radius: 4px;
            border-radius: 4px;
    font-size: 1rem;
    line-height: 1.3;
    margin-left: 0;
    margin-top : 30px;
    max-width: 400px;
    width : auto;
    min-width : 40px;
    padding: 15px;
    height : auto;
    float : left;
    position: relative;
}

 .chat-bubble-left p {
    margin: 0 0 10px;
}
 .chat-bubble-left p:last-of-type {
    margin-bottom: 0;
}

 .chat-bubble-left::after {
    border-right: 20px solid transparent;
    border-top: 20px solid #6dc5df;
    bottom: -18px;
    content: "";
    position: absolute;
    left: 20px;
}

.chat-bubble-left-menu-button{
    margin-left : 15px;
	float : left;
}

.chat-bubble-right {
    background: #e83e8c;
    -webkit-border-radius: 4px;
            border-radius: 4px;
    font-size: 1rem;
    line-height: 1.3;
    margin-right: 0;
    margin-top : 30px;
    max-width: 400px;
    padding: 15px;
    height : auto;
    float : right;
    position: relative;
}

 .chat-bubble-right p {
    margin: 0 0 10px;
}
 .chat-bubble-right p:last-of-type {
    margin-bottom: 0;
}

 .chat-bubble-right::after {
    border-left: 20px solid transparent;
    border-top: 20px solid #e83e8c;
    bottom: -18px;
    content: "";
    position: absolute;
    right: 20px;
}

.chat-bubble-right-menu-button{
    margin-right : 15px;
	float : right;
}

@media (min-width:150px){
	.chat-bubble-right {
		max-width : 90px;
	}
	.chat-bubble-left {
		max-width : 90px;
	}
}
@media (min-width:300px){
	.chat-bubble-right {
		max-width : 144px;
	}
	.chat-bubble-left {
		max-width : 144px;
	}
}
@media (min-width:400px){
	.chat-bubble-right {
		max-width : 270px;
	}
	.chat-bubble-left {
		max-width : 270px;
	}
}
@media (min-width:580px){
	.chat-bubble-right {
		max-width : 400px;
	}
	.chat-bubble-left {
		max-width : 400px;
	}
}

/* right nav start --------------------- */
.right-nav{
	height : 100%;
	width : 230px;
	background : transparent;
	right : 0px;
	top : 0px;
	position : absolute;
  	transition : right 0.3s ease-in-out;
	color : #000000;
  	z-index : 3000;
}
.right-nav-upper{
	height : 56px;
}
.right-nav-main{
	height : calc(100% - 56px);
	border-left-style : solid;
	border-left-width : 1px;
	border-left-color : #aaaaaa;
	border-top-style : solid;
	border-top-width : 1px;
	border-top-color : #aaaaaa;
	border-bottom-style : solid;
	border-bottom-width : 1px;
	border-bottom-color : #aaaaaa;
	overflow-y : scroll;
}
.content-margin-right{
	margin-right : 230px;
	transition : margin-right 0.5s ease-in-out;
}
@media (min-height : 300px){
	.right-nav{
		height : 100%;
	}	
}
@media (min-height : 480px){
	.right-nav{
		height : 100%;
	}	
}
@media (min-height : 600px){
	.right-nav{
		height : 100%;
	}	
}
@media (min-height : 800px){
	.right-nav{
		height : 100%;
	}	
}
@media (min-height : 992px){
	.right-nav{
		height : 100%;
	}	
}
@media (min-height : 1080px){
	.right-nav{
		height : 100%;
	}	
}
@media (min-height : 1200px){
	.right-nav{
		height : 100%;
	}	
}
/*right nav arrow----------------------*/
.right-nav-arrow{
	font-size : 20pt;
}
.right-nav-arrow-button{
	border : solid 1px #cccccc;
	color : #999999;
	text-decoration : none;
	border-radius : 50%;
	width : 32px;
	height : 32px;
	padding : 0;
	text-align : center;
	position : absolute;
	display : none;
	right : 0;
}
/* @media width---------------------- */
@media (min-width: 150px) {
  .right-nav{
  	right : -300px;
  }
  .content-margin-right{
  	margin-right : 0px;
  }
  .right-nav-arrow-button{
  	display : block;
  }
}
@media (min-width: 768px) {
  .right-nav{
  	right : 0px;
  }
  .content-margin-right{
  	margin-right : 230px;
  }
  .right-nav-arrow-button{
  	display : none;
  }
}

/*overlay-----------------*/
.custom-overlay{
	position: fixed;
  	top: 0;
  	left: 0;
  	right: 0;
  	bottom: 0;
  	display: none;
  	background-color: rgba(0, 0, 0, 0.1);
  	z-index : 2999;
  	width : 100%;
  	height : 100%;
}
.ul-cust{
	padding-left : 0px;
}
.p-custom{
	margin-bottom : 0;
}
.list-cust{
	max-height : 80px;
	height : 80px;
	list-style-type : none;
	border-bottom : solid 2px #aaaaaa;
	padding-left : 10px;
}
.list-cust:hover{
	background : #dddddd;
	cursor : pointer;
}


 /*misc ------------------------*/
}
.left-float{
	float : left;
}
.content-top-margin{
	margin-top : 30px;
}
.clear{clear:both;}
</style>