<script>
    $(document).ready(function(){
        getUserChat();
    });
    
    function getUserChat(){
        $.ajax({
            url : '<?= $uri_segment;?>getUser',
            type : 'post',
            dataType : 'JSON',
            processData: false,
            contentType: false,
            cache: false,
            async: false,
            success: function(data){
                if(data.status == true){
                    $("#userList").html(data.data);
                }
            },
            error:function(){
                toastr.error("Koneksi bermasalah", { timeOut: 2000, fadeOut: 2000 });
            }
        });
    }
    
    function getChatAwal(){
        $.ajax({
            url : '<?= $uri_segment;?>getData',
            type : 'post',
            dataType : 'JSON',
            processData: false,
            contentType: false,
            cache: false,
            async: false,
            success: function(data){
                if(data.status == true){
                    $("#chatfield").html(data.data);
                }
            },
            error:function(){
                toastr.error("Koneksi bermasalah", { timeOut: 2000, fadeOut: 2000 });
            }
        });
    }

    function loadChat(id){
        $.ajax({
            url : '<?= $uri_segment;?>getData',
            type : 'post',
            data: {'id' : id},
            dataType : 'JSON',
            success: function(data){
                if(data.status == true){
                    $("#chatfield").html(data.data);
                }else{
                    toastr.error(data.data, { timeOut: 2000, fadeOut: 2000 });
                }
            },
            error:function(){
                toastr.error("Koneksi bermasalah", { timeOut: 2000, fadeOut: 2000 });
            }
        });
    }

    $('#userList').on('click','.list-cust',function(){
        var data = $(this).attr('data');
        $('#cust_id').val(data);
        loadChat(data);
    });

    $("#send").on('click', function(){
        var data = $('#inputmsg').val().replace(/\n/g, "<br />");
        var id = $('#cust_id').val();
        if(data != '' || data != null){
            $.ajax({
                url: '<?= base_url('admin/chat/sendMsgAdmin/');?>',
                dataType: 'JSON',
                type: 'post',
                data:{
                    sendData: data,
                    cust_id: id
                },
                success: function(data){
                    if(data.status){
                        loadChat(id);
                        $('#inputmsg').val('');
                    }
                }
            });
        }
    });

    $("#chatfield").on('click', '.star-msg', function(){
        var id = $(this).attr('data');
        var user = $('#cust_id').val();
        $.ajax({
            url : '<?= $uri_segment . "starMessage";?>',
            data : {
                id : id
            },
            type : 'post',
            dataType : 'JSON',
            success : function(data){
                if(data.status == true){
                    toastr.success(data.alert, { timeOut: 2000, fadeOut: 2000 });
                    loadChat(user);
                }else{
                    toastr.error('failed, chat not starred', { timeOut: 2000, fadeOut: 2000 });
                }
            }
        });
    });

    $("#chatfield").on('click', '.delete-msg', function(){
        var id = $(this).attr('data');
        var user = $('#cust_id').val();
        $.ajax({
            url : '<?= $uri_segment . "deleteMessage";?>',
            data : {
                id : id
            },
            type : 'post',
            dataType : 'JSON',
            success : function(data){
                if(data.status == true){
                    toastr.success(data.alert, { timeOut: 2000, fadeOut: 2000 });
                    loadChat(user);
                    getUserChat();
                }else{
                    toastr.error('failed, chat not deleted', { timeOut: 2000, fadeOut: 2000 });
                }
            }
        });
    });
</script>