<div class="row">
  <div class="col-12">
    <div class="card content-margin-right content-top-margin">
      <div class="card-header">
        <h3 class="card-title"><b>Pasar Tiket Jojga</b>
        </h3>
        <h3 class="card-title"><b>Live Chat Admin v1.0</b></h3>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
		<div class="chat chatfield" id="chatfield">
      
    </div>
      <div class="row" style="margin-top:15px;">
        <div class="col-md-11">
          <input type="hidden" id="cust_id"/>
          <textarea class="form-control" name="inputmsg" id="inputmsg" style="width:100%;height:auto;min-height:50px;max-height:120px;resize:none;" placeholder="ketik pesan..."></textarea>
        </div>
        <div class="col-md-1">
    			<button id="send" class="btn btn-default" style="background-color:#4caf50;"><i style="color:white;" class="fa fa-send-o"></i></button>
        </div>
      </div>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>
  <!-- /.col -->
</div>
  <aside class="right-nav">
    <div class="right-nav-upper">
    </div>
    <div class="right-nav-main" id="userList">
      
    </div>
  </aside>