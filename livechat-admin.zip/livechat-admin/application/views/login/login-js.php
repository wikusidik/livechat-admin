<script>
    $(document).ready(function(){
        
    });
    function cekLogin(){
        status = true;
        $('#form-login .required').each(function(){
            if($(this).val() == ""){
            toastr.error( 'Ada inputan yang belum terisi', 'Gagal', { timeOut: 2000, fadeOut: 2000 });
            status = false;
            }
        });
        return status;
    }

    $('#form-login').submit(function(e){
        e.preventDefault();
        
        if(cekLogin()){
            let data = new FormData(this);
            var url  = "<?php echo base_url($uri_segment.'login_submit') ?>";
            $.ajax({
                url: url,
                type: "POST",
                data: data,
                dataType : "JSON",
                processData: false,
                contentType: false,
                cache: false,
                async: false,
                beforeSend:function(){
                    $('#submit').val("proses...");
                },
                success: function(data) {
                    if (data.status == true) {
                        window.location.href = '<?= base_url('admin/chat/');?>';
                    } else { 
                        $('#submit').val("Log In");

                        toastr.error( data.data, { timeOut: 2000, fadeOut: 2000 });
                        // location.reload();
                    }
                },
                error: function () {
                    toastr.error( 'Periksa Inputan Anda', { timeOut: 2000, fadeOut: 2000 });
                    // location.reload();
                }
            });
        }
    });
</script>