<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Starred extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->model('Star_model','chat');
		$this->load->model('Admin_model','admin');
	}

	public function index()
	{
		$data = array(
            'isi' => 'starred/main',
			'js' => 'starred/extra-js',
			'css' => 'starred/extra-css',
			'uri_segment' => base_url('admin/starred/'),
			'toastr' => true
        );
		$this->load->view('_templates/container',$data);
	}

	function getData(){
		$id = $this->input->post('id');
		$admin = $this->session->userdata('id');
		$data = $this->chat->getChatAdmin($id,$admin);
		$rows = '';
		$status = false;
		$star = '';
		foreach($data as $row){
			if($row->admin_starred == 1){
				$star = '<a class="dropdown-item star-msg" data="' . $row->id . '"><i class="fa fa-star"></i> Un-Star message</a>';
			}else{
				$star = '<a class="dropdown-item star-msg" data="' . $row->id . '"><i class="fa fa-star"></i> Star message</a>';
			}
			if($row->is_customer_send == 1){
				$chat = '<div class="chatspace">
							<div class="chat-bubble-left">' . $row->isi . '</div>
							<div class="chat-bubble-menu-button chat-bubble-left-menu-button dropdown-toggle" data-toggle="dropdown"></div>
							<div class="dropdown-menu" role="menu">' . $star . '
								<a class="dropdown-item delete-msg" user="' . $id . '" data="' . $row->id . '"><i class="fa fa-trash"></i> Delete message</a>
							</div>
						</div>';
			}else if($row->is_customer_send == 0){
				$chat = '<div class="chatspace">
							<div class="chat-bubble-right">' . $row->isi . '</div>
							<div class="chat-bubble-menu-button chat-bubble-right-menu-button dropdown-toggle" data-toggle="dropdown"></div>
							<div class="dropdown-menu">' . $star . '
								<a class="dropdown-item delete-msg" user="' . $id . '" data="' . $row->id . '"><i class="fa fa-trash"></i> Delete message</a>
							</div>
						</div>';
			}
			$rows .= $chat;
		}

		if(!empty($rows)){
			$status = true;
		}

		echo json_encode(array('status' => $status, 'data' => $rows));
	}

	function getUser(){
		$data = $this->chat->getUserChat();
		$rows = '';
		$status = false;
		foreach($data as $row){
			$list = '<div class="list-cust" data="'. $row->id .'"><p class="p-custom"><strong>'. $row->email .'</strong></p><p class="p-custom">'. $row->isi .'</p></div>';
			$rows .= $list;
		}

		if(!empty($rows)){
			$status = true;
		}

		echo json_encode(array('status' => $status, 'data' => $rows));
	}

	public function starMessage(){
		$id = $this->input->post('id');
		$isStarred = $this->db->select('admin_starred')->where('id_chat', $id)->get('tr_livechat')->row();
		
		$alert = '';
		if($isStarred->admin_starred == 0){
			$this->db->update('tr_livechat',['admin_starred' => 1], ['id_chat' => $id]);
			$alert = 'chat starred';
		}else if($isStarred->admin_starred == 1){
			$this->db->update('tr_livechat',['admin_starred' => 0], ['id_chat' => $id]);
			$alert = 'chat unstarred';
		}

		if($this->db->affected_rows() > 0){
			echo json_encode(array('status' => true, 'alert' => 'Success, ' . $alert));
		}else{
			echo json_encode(array('status' => false));
		}
	}

	public function deleteMessage(){
		$id = $this->input->post('id');

		$this->db->where('id_chat', $id);
		$this->db->update('tr_livechat',['admin_deleted' => 1]);
		
		if($this->db->affected_rows() > 0){
			echo json_encode(array('status' => true, 'alert' => 'Success, chat deleted'));
		}else{
			echo json_encode(array('status' => false));
		}
	}
}
