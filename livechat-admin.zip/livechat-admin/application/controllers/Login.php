<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct(){
		parent::__construct();
        // $this->load->model(['backend/survey/M_verifikasi_lapangan']);
    }
	public function index()
	{

		$data = array(
			'css' => 'login/login-css',
			'js' => 'login/login-js',
			'uri_segment' => 'login/'
		);
		
		$this->load->view('login/login',$data);
	}

	public function login_submit(){
		$uname = $this->input->post('uname');
		$passwd = md5($this->input->post('password'));
		$passwd = md5($passwd . 'pasartiket');
		$q = $this->db->select('id_admin id, username, password')->where(array('username' => $uname, 'deleted_at' => null))->get('tm_admin');
		$n = $q->num_rows();
		$status = false;
		$pesan = "username/password tidak diketahui";
		if($n > 0){
			$q = $q->row();
			if($passwd == $q->password){
				$status = true;
				$pesan = "masuk aja bro";
				$this->session->set_userdata('id',$q->id);
				$this->session->set_userdata('username',$q->username);
			}
		}
		echo json_encode(array('status' => $status,'data'=>$pesan));
	}
}
