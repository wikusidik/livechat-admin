<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Star_model extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	function getChatAdmin($user,$admin){
        
        $this->db->select('id_chat id, id_customer, id_admin, sent_time sent, is_customer_send, isi, admin_unread, admin_starred');
        
        $this->db->where(array(
                'admin_deleted' => 0,
                'admin_true_delete' => 0,
                'admin_starred' => 1
            )); //if user is admin
        $this->db->where('id_admin',$admin);
        $this->db->where('id_customer',$user);
        $this->db->order_by('sent_time','asc');
        
        return $this->db->get('tr_livechat')->result();
        
    }

    function getUserChat(){
        return $this->db->select('DISTINCT(a.id_customer) as id, a.isi as isi, b.email as email')
            ->where(array(
                'admin_deleted' => 0,
                'admin_true_delete' => 0,
                'admin_starred' => 1))
            ->join('tm_customer as b','a.id_customer = b.id_customer','inner')
            ->order_by('sent_time','desc')
            ->group_by('a.id_customer')
            ->get('tr_livechat as a')->result();
    }
    
    function deleteChat($user,$where){
        if($user == 1){
            $delete = array(
                'admin_deleted' => 1,
                'admin_unread' => 0,
                'admin_starred' => 0
            );
        }else if($user == 2){
            $delete = array(
                'customer_deleted' => 1
            );
        }
        foreach($where as $w){
            $this->db->update('tr_livechat',$delete,$w);
        }
    }
}